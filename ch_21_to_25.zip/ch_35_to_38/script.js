var a = Number(prompt("Please enter the marks obtain in 1st Subject"));
var b = Number(prompt("Please enter the marks obtain in 2nd Subject"));
var c = Number(prompt("Please enter the marks obtain in 3rd Subject"));
var d = Number(prompt("Please enter the marks obtain in 4th Subject"));
var e = Number(prompt("Please enter the marks obtain in 5th Subject"));
var f = 500;
var g = a+b+c+d+e;
var h= (g*100)/f;

alert("Total Marks = " + f);
alert("Total Marks Obtained = " + g);
alert("Perctange Obtained = " + h + "%")