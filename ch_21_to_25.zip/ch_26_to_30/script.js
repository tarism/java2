function myFunc() {
    var name = prompt("Please Enter Your Full Name", "TARIS MASIH");
    // document.getElementById('Name').innerHTML = 'Hello ' + name;

    var rightNow = new Date();
    var dated = prompt("Please Enter your Date Of Birth", "07");
    var mon = prompt("Please Enter your Month Of Birth", "FEB");
    var year = prompt("Please Enter your Year Of Birth", "1986");
    var otherday = mon + ' ' + dated + ', ' + year;
    var otherDay = new Date(otherday);
    // document.getElementById('DOB').innerHTML = ', Your date of birth is ' + otherDay;

    console.log("Hello " + name);
    console.log(" Your date of birth is " + otherDay);

    var Year = new Date().getFullYear();
    var tarisyear = new Date(otherday).getFullYear();
    var tarisy = Year - tarisyear;
    // document.getElementById('year').innerHTML = 'You are ' + tarisy + ' Years ';

    var month = new Date().getMonth();
    var tarismon = new Date(otherday).getMonth();
    var tarism = month - tarismon;
    // document.getElementById('mon').innerHTML = ' ' + tarism + ' Months ';

    var nDate = new Date().getDate();
    var tarisdate = new Date(otherday).getDate();
    var tarisd = Math.abs(nDate - tarisdate);
    // document.getElementById('days').innerHTML = ' ' + tarisd + ' Days ';

    var hours = new Date().getHours();
    var tarishours = new Date(otherday).getHours();
    var tarish = hours - tarishours;
    // document.getElementById('hours').innerHTML = ' ' + tarish + ' Hours ';

    var minutes = new Date().getMinutes();
    var tarisminutes = new Date(otherday).getMinutes();
    var tarismin = minutes - tarisminutes;
    // document.getElementById('minutes').innerHTML = ' ' + tarismin + ' Minutes ';

    var seconds = new Date().getSeconds();
    var tarissec = new Date(otherday).getDate();
    var tariss = seconds - tarissec;
    // document.getElementById('seconds').innerHTML = ' ' + tariss + ' Seconds old';

    console.log('You are ' + tarisy + ' Years ' + tarism + ' Months ' + tarisd + ' Days ' + tarish + ' Hours ' + tarismin + ' Minutes ' + tariss + ' Seconds old')

    var now = (new Date())-(new Date(otherDay));
    var newnow = parseInt(now / 1000 / 60 / 60 / 24)
    console.log("Your Age in DAYS " + newnow);

    var newyear = (parseInt(Year)) + 1;
    var birthdayCelebrationDate = mon + ' ' + dated + ', ' + newyear;
    var BirthdayCelebrationDate = new Date(birthdayCelebrationDate);
    var nextBirthday = BirthdayCelebrationDate.getTime() - rightNow.getTime();
    var nextbirthday = nextBirthday / (1000 * 60 * 60 * 24);
    var nextbd = Math.floor(nextbirthday);
    if (nextbd > 364) {
        var Newyear = newyear - 1;
    } else {
        var Newyear = newyear;
    }
    var newbirthday = mon + ' ' + dated + ', ' + Newyear;
    var newBirthday = new Date(newbirthday);
    var newBirthday = newBirthday.getTime() - rightNow.getTime();
    var newbirthday = newBirthday / (1000 * 60 * 60 * 24);
    var next = Math.floor(newbirthday);
    if (next == -1) {
        var nextbirth = 'Happy Birthday ' + name;
    } else if (next == 0) {
        var nextbirth = name + ' tommorrow is your birthday';
    } else {
        var nextbirth = 'Next birthday in ' + next + ' Days.';
    }
    // alert(birthdayCelebrationDate);
    // alert(BirthdayCelebrationDate);
    // alert(nextBirthday);
    // alert(nextbirthday);
    // alert(next);
    // 'Next birthday in ' +  + ' Days.'
    // document.getElementById('next').innerHTML = nextbirth;

    console.log(nextbirth)
}
myFunc()